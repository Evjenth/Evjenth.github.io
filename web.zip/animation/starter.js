function loadObjects(scene) {

    var loader = new THREE.OBJMTLLoader();
    var objects = loadObject(loader);
    var origo = new THREE.Vector3(0, 0, 0);

    var linelength = 4000;
    var material = new THREE.LineBasicMaterial({
        color: 0xff0000
    });
    var linegeo = new THREE.Geometry();
    linegeo.vertices.push(
        new THREE.Vector3(linelength, 0, 0),
        origo
    );
    var line = new THREE.Line(linegeo, material);

    scene.add(line);

    var material1 = new THREE.LineBasicMaterial({
        color: 0x00ff00
    });
    var linegeo1 = new THREE.Geometry();
    linegeo1.vertices.push(
        new THREE.Vector3(0, linelength, 0),
        origo
    );
    var line1 = new THREE.Line(linegeo1, material1);

    scene.add(line1);

    var material2 = new THREE.LineBasicMaterial({
        color: 0x0000ff
    });
    var linegeo2 = new THREE.Geometry();
    linegeo2.vertices.push(
        new THREE.Vector3(0, 0, linelength),
        origo
    );
    var line2 = new THREE.Line(linegeo2, material2);

    scene.add(line2);

    var frames = [];
    frames[0] = new THREE.Object3D(0, 0, 0);
    frames[1] = new THREE.Object3D(0, 0, 0);
    frames[1].position.y = 1350;
    frames[1].position.z = -170;
    frames[2] = new THREE.Object3D(0, 0, 0);
    frames[2].position.y = 50;
    frames[3] = new THREE.Object3D(0, 0, 0);
    frames[3].position.y = 1300;

    scene.add(frames[0]);
    frames[0].add(objects.o1);
    frames[0].add(frames[1]);
    frames[1].add(objects.o2);
    frames[1].add(frames[2]);
    frames[2].add(objects.o3);
    frames[2].add(frames[3]);
    frames[3].add(objects.o4);
    return frames;
}

function loadObject(loader, num) {
    var o1 = new THREE.Object3D();
    loader.load('models/realistic_rov.obj', 'models/realistic_rov.mtl', function (object) { o1.add(object); });
    o1.position.y = -1300;
    o1.position.z = 600;;
    o1.position.x = 800;
    o1.rotation.y = Math.PI / 2;
    o1.rotation.x = Math.PI / 2;

    var o2 = new THREE.Object3D();
    loader.load('models/base.obj', 'models/base.mtl', function (object) { o2.add(object); });
    o2.rotation.z = Math.PI;
    var o3 = new THREE.Object3D();
    loader.load('models/arm1.obj', 'models/arm1.mtl', function (object) { o3.add(object); });

    o3.rotation.z = Math.PI / 2;
    o3.rotation.y = Math.PI / 2;
    o3.scale.y = 3;
    o3.scale.z = 2;

    var o4 = new THREE.Object3D();
    loader.load('models/arm1.obj', 'models/arm1.mtl', function (object) { o4.add(object); });
    o4.rotation.z = Math.PI / 2;
    o4.scale.y = 3;
    o4.scale.z = 2;
    
    return {
        o1: o1,
        o2: o2,
        o3: o3,
        o4: o4
    }

}

function generateHeight(width, height) {
    var size = width * height, data = new Uint8Array(size),
    perlin = new ImprovedNoise(), quality = 1, z = Math.random() * 5;
    for (var j = 0; j < 4; j++) {
        for (var i = 0; i < size; i++) {
            var x = i % width, y = ~~(i / width);
            data[i] += Math.abs(perlin.noise(x / quality, y / quality, z) * quality * 1.75);
        }
        quality *= 1.2;
    }
    return data;
}

function generateTexture(data, width, height) {
    var canvas, canvasScaled, context, image, imageData,
    level, diff, vector3, sun, shade;
    vector3 = new THREE.Vector3(0, 0, 0);
    sun = new THREE.Vector3(1, 1, 1);
    sun.normalize();
    canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    context = canvas.getContext('2d');
    context.fillStyle = '#000';
    context.fillRect(0, 0, width, height);
    image = context.getImageData(0, 0, canvas.width, canvas.height);
    imageData = image.data;
    for (var i = 0, j = 0, l = imageData.length; i < l; i += 4, j++) {
        vector3.x = data[j - 2] - data[j + 2];
        vector3.y = 2;
        vector3.z = data[j - width * 2] - data[j + width * 2];
        vector3.normalize();
        shade = vector3.dot(sun);
        imageData[i] = (shade * 128) * (0.5 + data[j] * 0.007);
        imageData[i + 1] = (32 + shade * 96) * (0.5 + data[j] * 0.007);
        imageData[i + 2] = (shade * 96) * (0.5 + data[j] * 0.007);
    }
    context.putImageData(image, 0, 0);
    // Scaled 4x
    canvasScaled = document.createElement('canvas');
    canvasScaled.width = width * 4;
    canvasScaled.height = height * 4;
    context = canvasScaled.getContext('2d');
    context.scale(4, 4);
    context.drawImage(canvas, 0, 0);
    image = context.getImageData(0, 0, canvasScaled.width, canvasScaled.height);
    imageData = image.data;
    for (var i = 0, l = imageData.length; i < l; i += 4) {

        var v = ~~(Math.random() * 5);
        imageData[i] += v;
        imageData[i + 1] += v;
        imageData[i + 2] += v;
    }

    context.putImageData(image, 0, 0);
    return canvasScaled;
}



function gui() {
    var gui = new dat.GUI({
        height: 5 * 32 - 1
    });
    guiParams = {
        PER1: 10,
        PER2: 3,
        AMP1: 0.7,
        AMP2: 1.0

    };
    gui.add(guiParams, 'PER1', 1, 20).name('Period arm 1');
    gui.add(guiParams, 'PER2', 1, 20).name('Period arm 2');
    gui.add(guiParams, 'AMP1', 0.1, Math.PI / 4).name('Amplitude arm 1');
    gui.add(guiParams, 'AMP2', 0.1, Math.PI / 2).name('Amplitude arm 2');
    return guiParams;
}

function period(seconds) {
    return (Math.PI * 2) / seconds;
}

